name: Inception v2

This model is a replication of the model described in the "Going Deeper with Convolutions" by Christian Szegedy etc
http://www.cv-foundation.org/openaccess/content_cvpr_2015/papers/Szegedy_Going_Deeper_With_2015_CVPR_paper.pdf 


This model obtains a top-1 accuracy 67.5% and a top-5 accuracy 88.0% on the validation set, using just the center crop.

## License

This model is released for unrestricted use.
