#include <cfloat>
#include <vector>

#include "caffe/layers/eltwise_layer.hpp"
#include "caffe/net.hpp"

namespace caffe {

template <typename Ftype, typename Btype>
void EltwiseLayer<Ftype, Btype>::LayerSetUp(const vector<Blob*>& bottom,
      const vector<Blob*>& top) {
  CHECK(this->layer_param().eltwise_param().coeff_size() == 0
      || this->layer_param().eltwise_param().coeff_size() == bottom.size()) <<
      "Eltwise Layer takes one coefficient per bottom blob.";
  CHECK(!(this->layer_param().eltwise_param().operation()
      == EltwiseParameter_EltwiseOp_PROD
      && this->layer_param().eltwise_param().coeff_size())) <<
      "Eltwise layer only takes coefficients for summation.";
  op_ = this->layer_param_.eltwise_param().operation();
  // TBlob-wise coefficients for the elementwise operation.
  coeffs_ = vector<float>(bottom.size(), 1.F);
  if (this->layer_param().eltwise_param().coeff_size()) {
    for (int i = 0; i < bottom.size(); ++i) {
      coeffs_[i] = this->layer_param().eltwise_param().coeff(i);
    }
  }
  stable_prod_grad_ = this->layer_param_.eltwise_param().stable_prod_grad();
  shared_ = false;
}

template <typename Ftype, typename Btype>
void EltwiseLayer<Ftype, Btype>::Reshape(const vector<Blob*>& bottom,
      const vector<Blob*>& top) {
  const Net* pnet = this->parent_net();
  no_coeffs_ = pnet != nullptr && !pnet->inner_net();
  for (int i = 0; i < bottom.size() && no_coeffs_; ++i) {
    no_coeffs_ = no_coeffs_ && coeffs_[i] == 1.F;
  }
  shared_ = no_coeffs_ && pnet->eltwise_mem_sharing();
  for (int i = 1; i < bottom.size(); ++i) {
    CHECK(bottom[i]->shape() == bottom[0]->shape());
  }
  top[0]->ReshapeLike(*bottom[0]);
  // If max operation, we will initialize the vector index part.
  if (this->layer_param_.eltwise_param().operation() ==
      EltwiseParameter_EltwiseOp_MAX && top.size() == 1) {
    max_idx_.Reshape(bottom[0]->shape());
  }
  if (op_ == EltwiseParameter_EltwiseOp_SUM && no_coeffs_) {
    if (shared_) {
      for (int i = 0; i < bottom.size(); ++i) {
        bottom[i]->ShareDiff(*top[0]);
      }
      top[0]->ShareData(*bottom[0]);
    }
  }
}

template <typename Ftype, typename Btype>
void EltwiseLayer<Ftype, Btype>::Forward_cpu(
    const vector<Blob*>& bottom, const vector<Blob*>& top) {
  int* mask = nullptr;
  const Ftype* bottom_data_a = nullptr;
  const Ftype* bottom_data_b = nullptr;
  const int count = top[0]->count();
  Ftype* top_data = top[0]->mutable_cpu_data<Ftype>();
  switch (op_) {
  case EltwiseParameter_EltwiseOp_PROD:
    caffe_mul(count, bottom[0]->cpu_data<Ftype>(), bottom[1]->cpu_data<Ftype>(), top_data);
    for (int i = 2; i < bottom.size(); ++i) {
      caffe_mul(count, top_data, bottom[i]->cpu_data<Ftype>(), top_data);
    }
    break;
  case EltwiseParameter_EltwiseOp_SUM:
    if (shared_ && no_coeffs_) {
      for (int i = 1; i < bottom.size(); ++i) {
        caffe_axpy(count, Ftype(1), bottom[i]->cpu_data<Ftype>(), top_data);
      }
    } else {
      caffe_set(count, Ftype(0), top_data);
      // TODO(shelhamer) does BLAS optimize to sum for coeff = 1?
      for (int i = 0; i < bottom.size(); ++i) {
        caffe_axpy(count, Ftype(coeffs_[i]), bottom[i]->cpu_data<Ftype>(), top_data);
      }
    }
    break;
  case EltwiseParameter_EltwiseOp_MAX:
    // Initialize
    mask = max_idx_.mutable_cpu_data();
    caffe_set(count, -1, mask);
    caffe_set(count, -max_dtype<Ftype>(), top_data);
    // bottom 0 & 1
    bottom_data_a = bottom[0]->cpu_data<Ftype>();
    bottom_data_b = bottom[1]->cpu_data<Ftype>();
    for (int idx = 0; idx < count; ++idx) {
      if (bottom_data_a[idx] > bottom_data_b[idx]) {
        top_data[idx] = bottom_data_a[idx];  // maxval
        mask[idx] = 0;  // maxid
      } else {
        top_data[idx] = bottom_data_b[idx];  // maxval
        mask[idx] = 1;  // maxid
      }
    }
    // bottom 2++
    for (int blob_idx = 2; blob_idx < bottom.size(); ++blob_idx) {
      bottom_data_b = bottom[blob_idx]->cpu_data<Ftype>();
      for (int idx = 0; idx < count; ++idx) {
        if (bottom_data_b[idx] > top_data[idx]) {
          top_data[idx] = bottom_data_b[idx];  // maxval
          mask[idx] = blob_idx;  // maxid
        }
      }
    }
    break;
  default:
    LOG(FATAL) << "Unknown elementwise operation.";
  }
}

template <typename Ftype, typename Btype>
void EltwiseLayer<Ftype, Btype>::Backward_cpu(const vector<Blob*>& top,
    const vector<bool>& propagate_down, const vector<Blob*>& bottom) {
  const int* mask = nullptr;
  const int count = top[0]->count();
  const Btype* top_data = top[0]->cpu_data<Btype>();
  const Btype* top_diff = top[0]->cpu_diff<Btype>();
  for (int i = 0; i < bottom.size(); ++i) {
    if (propagate_down[i]) {
      const Btype* bottom_data = bottom[i]->cpu_data<Btype>();
      Btype* bottom_diff = bottom[i]->mutable_cpu_diff<Btype>();
      switch (op_) {
      case EltwiseParameter_EltwiseOp_PROD:
        if (stable_prod_grad_) {
          bool initialized = false;
          for (int j = 0; j < bottom.size(); ++j) {
            if (i == j) { continue; }
            if (!initialized) {
              caffe_copy(count, bottom[j]->cpu_data<Btype>(), bottom_diff);
              initialized = true;
            } else {
              caffe_mul(count, bottom[j]->cpu_data<Btype>(), bottom_diff,
                        bottom_diff);
            }
          }
        } else {
          caffe_div(count, top_data, bottom_data, bottom_diff);
        }
        caffe_mul(count, bottom_diff, top_diff, bottom_diff);
        break;
      case EltwiseParameter_EltwiseOp_SUM:
        if (!no_coeffs_) {
          caffe_cpu_scale(count, Btype(coeffs_[i]), top_diff, bottom_diff);
        } else if (!shared_) {
          caffe_copy(count, top_diff, bottom_diff);
        }
        break;
      case EltwiseParameter_EltwiseOp_MAX:
        mask = max_idx_.cpu_data();
        for (int index = 0; index < count; ++index) {
          Btype gradient = 0;
          if (mask[index] == i) {
            gradient += top_diff[index];
          }
          bottom_diff[index] = gradient;
        }
        break;
      default:
        LOG(FATAL) << "Unknown elementwise operation.";
      }
    }
  }
}

INSTANTIATE_CLASS_FB(EltwiseLayer);
REGISTER_LAYER_CLASS(Eltwise);

}  // namespace caffe
