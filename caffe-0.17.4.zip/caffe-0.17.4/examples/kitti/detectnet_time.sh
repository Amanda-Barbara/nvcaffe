build/tools/caffe time -model examples/kitti/detectnet_network.prototxt $@
